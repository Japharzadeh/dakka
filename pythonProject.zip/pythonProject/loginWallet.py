import os
from getpass import getpass
from hashlib import sha256
from colorama import init


def login():
    init()
    from termcolor import colored
    dicrectory = "C:\\DakkaCoin"
    listdir = os.listdir(dicrectory)
    print(listdir)
    walletname = input("Choose a wallet: ")
    if walletname in listdir:
        password = getpass(prompt="Enter Password: ")
        file = open(f"{dicrectory}\\{walletname}", "r")
        hash_object = sha256(password.encode('utf-8'))
        hex_dig = hash_object.hexdigest()
        if hex_dig == file.readline()[:-1]:
            print(colored("Done", "green"))
            return True
        else:
            print(colored("password is incorrect", "red"))
            return False
    else:
        print(colored("can't find this wallet", "yellow"))
        return False