import generator


def gen():
    x = 0
    t = "D"
    while x < 40:
        m = generator.rand(4)
        t = t + m
        x = x + 1
    return t
