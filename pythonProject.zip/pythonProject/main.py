import loginWallet
import CreatWallet
from colorama import init
from termcolor import colored
import os
import socketio
import threading


sio = socketio.Client()
init()

def home():
    inp = input("[1]CONNECT TO WALLET\n\n[2]CREATE NEW WALLET")

    if inp == "1" or inp.lower() == "connect to wallet":
        os.system('cls')
        if loginWallet.login() == True:
            ip = input(colored("ip list: http://dakkacoin.com/iplist\nEnter ip address: ", "yellow"))
            sio.connect(f'http://{ip}:4427')
            send_thread = threading.Thread(target=send)
            send_thread.start()
            sio.wait()

        else:
            loginWallet.login()

    elif inp == "2" or inp.lower() == "create new wallet":
        os.system('cls')

        if CreatWallet.main() == True:
            pass
        else:
            CreatWallet.main()
    else:
        os.system('cls')
        print(colored("*************************\nPLEASE TRY AGAIN (1 OR 2)\n*************************", "red"))
        home()


@sio.event
def connect():
    print(colored('Connected to the server', "green"))


def send():
    sio.send("/start")
    return

@sio.event
def message(data):
    print(data)
home()

