from time import localtime
import generator


# making blocks
class blockGen:

    # generat block
    def gen(self):
        genwall = {
            "genY": f"{localtime().tm_year}",
            "genM": f"{localtime().tm_mon}",
            "genD": f"{localtime().tm_mday}",
            "genHMS": f"{localtime().tm_hour}: {localtime().tm_min}: {localtime().tm_sec}",
            "genBy": f"{self}"
        }
        return genwall

    # trans actions
    def trans(self, fromwall):
        transwall = {
            "transY": f"{localtime().tm_year}",
            "transM": f"{localtime().tm_mon}",
            "transD": f"{localtime().tm_mday}",
            "transHMS": f"{localtime().tm_hour}: {localtime().tm_min}: {localtime().tm_sec}",
            "transFrom": f"{fromwall}",
            "transTo": f"{self}"
        }
        return transwall


# block name
def genname():
    counter = 0
    name = ""
    while counter < 8:
        char = generator.rand(2)
        name = name + char
        counter = counter + 1
    return name
print(genname())