from random import randrange as random


def rand(num):
    randone = random(1, num)
    if randone == 1:
        char = random(48, 58)
    elif randone == 2:
        char = random(65, 91)
    else:
        char = random(97, 123)
    return chr(char)
