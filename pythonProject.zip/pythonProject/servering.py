from flask import Flask, request
from flask_socketio import SocketIO, send
import socketio as iosock
import threading


app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
socketio = SocketIO(app)

miners = []

sio = iosock.Client()

@socketio.on('message')
def handle_message(msg):
    client_ip = request.remote_addr
    if msg == '/start':
        miners.append(client_ip)
        send_thread = threading.Thread(target=minerstest, args=miners)
        send_thread.start()
        sio.wait()
        send(miners, broadcast=True)


def minerstest(miners):
    for x in miners:
        try:
            sio.connect(f'http://{x}:4427')
            print(x)
        except:
            miners.remove()

if __name__ == '__main__':
    # Use '0.0.0.0' to make the server accessible externally
    socketio.run(app, host='0.0.0.0', port=4427, debug=True)
