from colorama import init
from termcolor import colored
import genWall
import hashlib
import os
from getpass import getpass
import sqlite3
import datetime


con = sqlite3.connect('wallet')
cur = con.cursor()

def main():
    directory = "C:\\DakkaCoin"
    init()
    try:
        os.mkdir(directory)
    except:
        pass
    wallName = input("Enter wallet name: ")
    wallPassword = getpass(prompt="Enter wallet password: ")
    conwallPassword = getpass(prompt="Confirm wallet password: ")
    walletname = genWall.gen()
    if wallPassword == conwallPassword:
        try:
            file = open(f"{directory}\\{wallName}", "x")
            hash_object = hashlib.sha256(wallPassword.encode('utf-8'))
            hex_dig = hash_object.hexdigest()
            file.writelines(f"{hex_dig}\n{walletname}")
            file.close()
            return True
        except:
            print(colored("Error", "red"))
            return False
        print(colored("Ok", "green"))
        cur.execute(f"""CREATE TABLE [{walletname}](
                [dwm] TEXT, 
                [lv] TEXT, 
                [psd] TEXT);""")
        cur.execute(f"""
            INSERT INTO {walletname} (dwm, lv, psd) VALUES 
                ('{datetime.datetime.now()}', '{datetime.datetime.now()}', '{hex_dig}');
                """)
        con.commit()
        con.close()
        return True
    else:
        print(colored("Not match", "red"))
